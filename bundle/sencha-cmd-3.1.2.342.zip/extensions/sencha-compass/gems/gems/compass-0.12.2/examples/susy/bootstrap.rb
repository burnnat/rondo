require File.join(File.dirname(__FILE__), '..', 'downloader')

install_from_github('ericam', 'compass-susy-plugin', 'susy')
